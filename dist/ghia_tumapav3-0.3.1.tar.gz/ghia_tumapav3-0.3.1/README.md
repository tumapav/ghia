# GHIA I.
A tool for automatic issue assigning of GitHub issues

**More information at:**
https://github.com/cvut/ghia/tree/basic
