from .web import create_app
from .cli import ghia


def main():
    ghia()
