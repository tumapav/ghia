from .ghia import main


main()
